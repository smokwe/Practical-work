﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using WpfAppJSONPlaceholder.Models;
using WpfAppJSONPlaceholder.Services;
using Newtonsoft.Json;

namespace WpfAppJSONPlaceholder
{
    public partial class MainWindow : Window
    {
        private List<User> _users;
        private ApiService _apiService;

        public MainWindow()
        {
            InitializeComponent();
            _apiService = new ApiService();
            LoadUsers();
        }
        private async void LoadUsers()
        {
            _users = await _apiService.GetUsersAsync();
            UsersListView.ItemsSource = _users;
        }
        // поиск
        private void SearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            var searchQuery = SearchBox.Text.ToLower();
            var filteredUsers = _users.Where(user => user.Name.ToLower().Contains(searchQuery)).ToList();
            UsersListView.ItemsSource = filteredUsers;
        }       
        private void UsersListView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (UsersListView.SelectedItem is User selectedUser)
            {
                var detailsWindow = new UserDetailsWindow(selectedUser);
                detailsWindow.ShowDialog();
            }
        }
    }
}
