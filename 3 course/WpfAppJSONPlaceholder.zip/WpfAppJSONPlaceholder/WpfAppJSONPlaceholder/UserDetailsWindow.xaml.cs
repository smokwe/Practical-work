﻿using System.Windows;
using WpfAppJSONPlaceholder.Models;
using WpfAppJSONPlaceholder.Services;
using Newtonsoft.Json;


namespace WpfAppJSONPlaceholder
{
    public partial class UserDetailsWindow : Window
    {
        public UserDetailsWindow(User user)
        {
            InitializeComponent();
            DataContext = user;
        }
    }
}
